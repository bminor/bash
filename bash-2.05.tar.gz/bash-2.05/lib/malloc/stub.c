void
bash_malloc_stub()
{
}
