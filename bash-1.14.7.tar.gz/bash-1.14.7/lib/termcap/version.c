/* Make the library identifiable with the RCS ident command.  */
static char *version_string = "\n$Version: GNU termcap 1.2 $\n";
