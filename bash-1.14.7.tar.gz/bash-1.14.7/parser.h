/* parser.h -- Everything you wanted to know about the parser, but were
   afraid to ask. */

#if !defined (_PARSER_H)
#  define _PARSER_H
#  include "command.h"
#  include "input.h"
#endif /* _PARSER_H */
