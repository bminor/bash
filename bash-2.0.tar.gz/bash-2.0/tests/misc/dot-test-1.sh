echo this is $0
. ./dot-test-1.sub
echo after . dot-test-1.sub
