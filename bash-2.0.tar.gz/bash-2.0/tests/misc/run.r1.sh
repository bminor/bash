../../bash redir.t1.sh
