recho "$@"
